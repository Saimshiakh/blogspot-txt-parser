<?php 

header('Content-type: application/json');

$conents_arr = file('file.txt', FILE_IGNORE_NEW_LINES);

/*
	# Remove empty array elements
*/
$conents_arr = array_filter($conents_arr);

/*
	# Remove some unwanted characters in a string
*/
foreach($conents_arr as $key=>$value)
{
	if(!empty(trim($value, "\r")))
	{
		if (strpos($value, ':') !== false) 
		{
			$position[] = strpos($value, ':', 0);
			$get_key = substr($value, 0, strpos($value, ':', 0));			

			if(preg_match('/"/', str_replace(':', '', trim(substr($value, strpos($value, ':', 0))))))
			{
				$new_arr[$get_key]  = str_replace('"', '', trim(str_replace(':', '', trim(substr($value, strpos($value, ':', 0))))));
			}
			elseif(preg_match('/tags/', $get_key))
			{
				$new_arr[$get_key]  = explode(',', trim(str_replace(':', '', trim(substr($value, strpos($value, ':', 0))))));
			}
			elseif(preg_match('/published/', $get_key))
			{
				$new_arr[$get_key]  = (boolean) str_replace(':', '', trim(substr($value, strpos($value, ':', 0))));
			}
			else
			{
				// $new_arr[$get_key]  = '"'.trim(str_replace(':', '', trim(substr($value, strpos($value, ':', 0))))).'"';
				$new_arr[$get_key]  = trim(str_replace(':', '', trim(substr($value, strpos($value, ':', 0)))));
			}		    
		}
		else
		{
			$other_arr[] = trim(preg_replace('/-+/', '', $value));			
		}		
	}    
}

$other_arr = array_filter($other_arr);
$array_1['short-content'] = str_replace("\"", '', $other_arr[2] .' '. $other_arr[3]);
$array_1['content'] = str_replace("\"", '', $other_arr[4] .' '. $other_arr[5] .' '. $other_arr[6] .' '. $other_arr[7]);

$final_array = array_merge($new_arr, $array_1);
echo "<pre>";
// print_r($new_arr);
//print_r($array_1);
print_r($final_array);
print_r(json_encode($final_array));




